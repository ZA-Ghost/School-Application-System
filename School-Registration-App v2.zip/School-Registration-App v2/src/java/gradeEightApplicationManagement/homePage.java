package gradeEightApplicationManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class homePage extends dbConnection {

    public ResultSet unreviewedApplications() {
        ResultSet resultSet = null;
        Connection connection = null;
        PreparedStatement statement = null;
        
        try {
            connection = getConnection();
            String sql = "SELECT * FROM registration WHERE grade = 'grade8'";
            statement = connection.prepareStatement(sql);
            
            
            resultSet = statement.executeQuery();
        } catch (SQLException e) {
            System.out.println("Error during database operation.");
            e.printStackTrace();
        }
        
        return resultSet; // Return ResultSet to be processed in JSP
    }
}
