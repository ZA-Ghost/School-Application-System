package gradeNineApplicationManagement;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {
    private String jdbcURL = "jdbc:mysql://localhost:3306/registration";
    private String jdbcUsername = "root"; 
    private String jdbcPassword = "";      

    public Connection getConnection() {
        Connection connection = null;
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Failed to establish a connection to the database.");
            e.printStackTrace();
        }
        return connection;
    }
}
