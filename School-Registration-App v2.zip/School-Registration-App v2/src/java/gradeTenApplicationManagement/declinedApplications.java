package gradeTenApplicationManagement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class declinedApplications extends dbConnection {

    public ResultSet retrieveDeclinedApplications() {
        ResultSet resultSet = null;
        Connection connection = null;
        PreparedStatement statement = null;
        
        try {
            connection = getConnection();
            String sql = "SELECT * FROM reviewed WHERE grade = 'grade10' AND decision = 'Declined'";
            statement = connection.prepareStatement(sql);
            
            resultSet = statement.executeQuery();
        } catch (SQLException e) {
            System.out.println("Error during database operation.");
            e.printStackTrace();
        }
        
        return resultSet; // Return ResultSet to be processed in JSP
    }
}
