package overallApplicationManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReviewedApplications extends dbConnection {

    public ResultSet retrieveReviewedApplications() {
        ResultSet resultSet = null;
        Connection connection = null;
        PreparedStatement statement = null;
        
        try {
            connection = getConnection();
            String sql = "SELECT * FROM reviewed WHERE decision = 'Accepted'";
            statement = connection.prepareStatement(sql);
            
            resultSet = statement.executeQuery();
        } catch (SQLException e) {
            System.out.println("Error during database operation.");
            e.printStackTrace();
        }
        
        return resultSet; // Return ResultSet to be processed in JSP
    }
}
