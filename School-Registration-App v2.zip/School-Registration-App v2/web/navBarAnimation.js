function toggleMenu() {
            const menu = document.getElementById("menu");
            const contentContainer = document.querySelector(".content-container");
            if (menu.style.transform === "translateX(-250px)") {
                menu.style.transform = "translateX(0)";
                contentContainer.style.marginLeft = "250px";
            } else {
                menu.style.transform = "translateX(-250px)";
                contentContainer.style.marginLeft = "0";
            }
        }
        
document.getElementById("toggleButton").addEventListener("click", toggleMenu);