document.querySelector('.search-input').addEventListener('input', function () {
    let filter = this.value.toUpperCase();
    let table = document.querySelector('table');
    let tr = table.getElementsByTagName('tr');

    // Loop through all table rows (except the header row)
    for (let i = 1; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td');
        let rowContainsFilter = false;

        // Check each cell in the row
        for (let j = 0; j < td.length; j++) {
            if (td[j]) {
                if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                    rowContainsFilter = true;
                    break;
                }
            }
        }

        // Show or hide the row based on whether it contains the filter text
        if (rowContainsFilter) {
            tr[i].style.display = '';
        } else {
            tr[i].style.display = 'none';
        }
    }
});
